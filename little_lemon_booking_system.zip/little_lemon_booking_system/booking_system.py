# Implementation Script for Little Lemon Booking System

import mysql.connector

# Step 1: Connect to MySQL and Create Database
def create_database(cursor):
    cursor.execute("CREATE DATABASE IF NOT EXISTS LittleLemonBooking;")
    cursor.execute("USE LittleLemonBooking;")

# Step 2: Create Tables
def create_tables(cursor):
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Customers (
        CustomerID INT AUTO_INCREMENT PRIMARY KEY,
        FirstName VARCHAR(50),
        LastName VARCHAR(50),
        Email VARCHAR(100)
    );
    """)
    
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Bookings (
        BookingID INT AUTO_INCREMENT PRIMARY KEY,
        CustomerID INT,
        BookingDate DATE,
        CheckInDate DATE,
        CheckOutDate DATE,
        RoomType VARCHAR(50),
        TotalAmount DECIMAL(10, 2),
        Status VARCHAR(50) DEFAULT 'Pending',
        FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
    );
    """)

# Step 3: Create Stored Procedures
def create_procedures(cursor):
    cursor.execute("""
    DELIMITER //

    CREATE PROCEDURE GetMaxQuantity()
    BEGIN
        SELECT MAX(TotalAmount) AS MaxQuantity FROM Bookings;
    END //

    DELIMITER ;
    """)

    cursor.execute("""
    DELIMITER //

    CREATE PROCEDURE ManageBooking(
        IN booking_id INT,
        IN action VARCHAR(50)
    )
    BEGIN
        IF action = 'Confirm' THEN
            UPDATE Bookings SET Status = 'Confirmed' WHERE BookingID = booking_id;
        ELSEIF action = 'Cancel' THEN
            UPDATE Bookings SET Status = 'Cancelled' WHERE BookingID = booking_id;
        END IF;
    END //

    DELIMITER ;
    """)

    cursor.execute("""
    DELIMITER //

    CREATE PROCEDURE UpdateBooking(
        IN booking_id INT,
        IN check_in DATE,
        IN check_out DATE,
        IN room_type VARCHAR(50),
        IN total_amount DECIMAL(10, 2)
    )
    BEGIN
        UPDATE Bookings
        SET CheckInDate = check_in,
            CheckOutDate = check_out,
            RoomType = room_type,
            TotalAmount = total_amount
        WHERE BookingID = booking_id;
    END //

    DELIMITER ;
    """)

    cursor.execute("""
    DELIMITER //

    CREATE PROCEDURE AddBooking(
        IN customer_id INT,
        IN booking_date DATE,
        IN check_in DATE,
        IN check_out DATE,
        IN room_type VARCHAR(50),
        IN total_amount DECIMAL(10, 2)
    )
    BEGIN
        INSERT INTO Bookings (CustomerID, BookingDate, CheckInDate, CheckOutDate, RoomType, TotalAmount)
        VALUES (customer_id, booking_date, check_in, check_out, room_type, total_amount);
    END //

    DELIMITER ;
    """)

    cursor.execute("""
    DELIMITER //

    CREATE PROCEDURE CancelBooking(
        IN booking_id INT
    )
    BEGIN
        UPDATE Bookings SET Status = 'Cancelled' WHERE BookingID = booking_id;
    END //

    DELIMITER ;
    """)

# Step 4: Python Functions to Call Procedures
def add_booking(cursor, customer_id, booking_date, check_in, check_out, room_type, total_amount):
    cursor.callproc('AddBooking', [customer_id, booking_date, check_in, check_out, room_type, total_amount])
    conn.commit()
    print("Booking added successfully")

def cancel_booking(cursor, booking_id):
    cursor.callproc('CancelBooking', [booking_id])
    conn.commit()
    print("Booking cancelled successfully")

def update_booking(cursor, booking_id, check_in, check_out, room_type, total_amount):
    cursor.callproc('UpdateBooking', [booking_id, check_in, check_out, room_type, total_amount])
    conn.commit()
    print("Booking updated successfully")

def manage_booking(cursor, booking_id, action):
    cursor.callproc('ManageBooking', [booking_id, action])
    conn.commit()
    print(f"Booking {action.lower()}ed successfully")

def get_max_quantity(cursor):
    cursor.callproc('GetMaxQuantity')
    for result in cursor.stored_results():
        print("Max Quantity:", result.fetchone()[0])

# Step 5: Main Execution
if __name__ == "__main__":
    conn = mysql.connector.connect(
        host="localhost",
        user="your_username",
        password="your_password"
    )
    cursor = conn.cursor()

    # Create Database and Tables
    create_database(cursor)
    create_tables(cursor)

    # Create Procedures
    create_procedures(cursor)

    # Example Usage
    add_booking(cursor, 1, '2024-05-01', '2024-06-01', '2024-06-05', 'Deluxe', 500.00)
    get_max_quantity(cursor)
    manage_booking(cursor, 1, 'Confirm')
    update_booking(cursor, 1, '2024-06-02', '2024-06-06', 'Suite', 750.00)
    cancel_booking(cursor, 1)

    cursor.close()
    conn.close()
