# Little Lemon Booking System

This repository contains the implementation of a booking system for Little Lemon. It includes the database schema, stored procedures, and Python scripts for managing bookings.

## Database Schema

The database consists of two tables: `Customers` and `Bookings`. Below is the ER diagram:

![ER Diagram](er_diagram.png)

## Stored Procedures

The following stored procedures are implemented:

- `GetMaxQuantity()`: Retrieves the maximum booking amount.
- `ManageBooking(booking_id, action)`: Confirms or cancels a booking.
- `UpdateBooking(booking_id, check_in, check_out, room_type, total_amount)`: Updates booking details.
- `AddBooking(customer_id, booking_date, check_in, check_out, room_type, total_amount)`: Adds a new booking.
- `CancelBooking(booking_id)`: Cancels a booking.

## Python Scripts

The provided Python script connects to the MySQL database and calls the stored procedures. To run the script, ensure you have the `mysql-connector-python` package installed:

```bash
pip install mysql-connector-python
